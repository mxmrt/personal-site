# maxmartinelli.com

Personal site. Static HTML, deployed on Cloudflare Pages.

## Structure

```
├── index.html              # Main site (About + Articles tabs)
├── articles/
│   ├── template.html       # Copy this to create new articles
│   └── your-article.html
└── README.md
```

## Adding an article

1. Copy `articles/template.html` → `articles/your-slug.html`
2. Edit the title, date, tag, and content
3. Add a list item in `index.html` under the `article-list` section
4. Commit & push — Cloudflare Pages auto-deploys

## Deploy to Cloudflare Pages

1. Push this repo to GitHub
2. Go to [Cloudflare Pages](https://pages.cloudflare.com) → Create a project
3. Connect your GitHub repo
4. Build settings: leave blank (no build step needed)
5. Deploy

Your site will be live at `your-project.pages.dev`. Add a custom domain in the Cloudflare dashboard.
